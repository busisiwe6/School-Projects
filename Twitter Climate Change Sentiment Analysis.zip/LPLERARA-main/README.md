Twitter Sentiment Classification

Welcome to the Twitter Sentiment Classification project!

The Twitter Sentiment Classification project aims to create a machine learning model that
can classify whether a person believes in climate change or not, based on their tweets. This
project is motivated by the growing interest of companies in understanding consumer
sentiment towards climate change and its impact on their products and services.
Many companies today are dedicated to reducing environmental impact and offering
sustainable solutions. By determining how people perceive climate change and whether they
consider it a real threat, companies can gain valuable insights to inform their market
research efforts and develop effective marketing strategies.
The goal of this project is to build an accurate and robust machine learning model that can
classify tweets as either &quot;believes in climate change&quot; or &quot;does not believe in climate
change.&quot; By analyzing a diverse range of tweets, companies can access a broad base of
consumer sentiment and better understand the attitudes and opinions surrounding climate
change.

Team members
Neo Nenzhelele - nenzneo@gmail.com
Sandile Khumalo - sandilemtungwa16@gmail.com
Busisiwe Socatsha - bysirose459@gmail.com
Maseru Mashiloane - maserumashiloane@gmail.com
Lehakoe P Lerara - lplerara@gmail.com
Vasco Eti - vascoeti1992@gmail.com

Key Features
 Data-driven approach: The model is trained using a large dataset of tweets, allowing
it to learn patterns and correlations between the text content and the sentiment
expressed.
 Machine learning classification: The project utilizes popular machine learning
algorithms and techniques to classify tweets into two sentiment categories: &quot;believes
in climate change&quot; or &quot;does not believe in climate change.&quot;
 Generalizability: The model aims to perform well on novel tweet data, meaning it can
handle tweets that it hasn&#39;t seen during training, providing reliable predictions in real-
world scenarios.

Repository Structure
The project repository is organized as follows:

README.md: The README file you are currently reading, providing an overview of
the project and instructions for usage.

Train.csv: This is the data used to train our model.

Test.csv: This is the data used to test our model.

Sample Submission.csv: It is an example of what our submission file should look like. 

Please refer to the specific sections and files in the repository for detailed information.
 

External links
https://www.comet.com/kwanelesk/general/ab22d76c96f445dd9de295c208c4986f
https://github.com/LPLERARA/LPLERARA.git
https://github.com/M453ru/TeamNM1.git
https://www.canva.com/design/DAFlomaDe1k/4hnCY1mq_gyu7NncQyz8Rw/edit?utm_content=DAFlomaDe1k&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton
https://trello.com/invite/b/Zj09Py09/ATTId6e7754b16114e8c5cd0b4c83dc728030C75411D/nm1-advanced-classification

We appreciate your interest and hope that this project provides valuable insights into the
sentiment surrounding climate change on Twitter.
